<?php
ini_set('memory_limit', '-1');
include("../connect.php");
include("../functions.php");
if(isset($_POST['rowNumber'])){
    $i = $_POST['rowNumber'];
    $rosterName = $_POST['filename'];
    $rosterId = $_POST['rosterId'];
    $rosterPath =  $_SERVER['DOCUMENT_ROOT'].DIRECTORY_SEPARATOR."route".DIRECTORY_SEPARATOR."uploads".DIRECTORY_SEPARATOR.$rosterName;
    set_include_path(get_include_path() . PATH_SEPARATOR . 'Classes/');

    /** PHPExcel_IOFactory */
    include '../excel/Classes/PHPExcel/IOFactory.php';
    $returnData = array("rowNumber"=>"", "data"=>"", "end"=>0, "fileName"=>$rosterName, "totalRows"=>"");
    try {
    	$objPHPExcel = PHPExcel_IOFactory::load($rosterPath);
    	$sheetData = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
        $returnData['totalRows'] = count($sheetData);
        if(isset($sheetData[$i])){
            $returnData['rowNumber'] = $i+1;
            $row = $sheetData[$i];

            $customer = $row["A"];
            $address = $row["B"];
            $address2 = $row["C"];
            $pincode = $row["D"];
            $city = $row["E"];


            if(intval($pincode)){
                $latLongArray = array();
                $latLonAddress = $address.", ".$address2.", ".$city;
                $latLongArray = get_lat_long($latLonAddress);
                $latitude = $latLongArray[0];
                $longitude = $latLongArray[1];

                if($latitude !== 0 && $longitude !== 0){
                    $contentArray = array();
                    $contentArray['excelid'] = $rosterId;
                    $contentArray['latitude'] = $latitude;
                    $contentArray['longitude'] = $longitude;
                    $contentArray['customer'] = trim($customer);
                    $contentArray['address'] = trim($address);
                    $contentArray['address2'] = trim($address2);
                    $contentArray['pincode'] = trim($pincode);
                    $contentArray['city'] = trim($city);
                    addData("route_excel_data", $contentArray);
                }
            }
            echo json_encode($returnData);
        }else{
            $returnData['end'] = "1";
            $returnData['rowNumber'] = $returnData['totalRows'];
            echo json_encode($returnData);
        }
    } catch(Exception $e) {
    	die('Error loading file "'.pathinfo($rosterPath,PATHINFO_BASENAME).'": '.$e->getMessage());
    }
}

function get_lat_long($address){
    $json = file_get_contents("http://maps.google.com/maps/api/geocode/json?address=".urlencode($address)."&sensor=false");
    $json = json_decode($json);

    $status = $json->{'status'};

    if($status == "ZERO_RESULTS"){
        $lat = 0;
        $lon = 0;
    }else{
        $lat = $json->{'results'}[0]->{'geometry'}->{'location'}->{'lat'};
        $long = $json->{'results'}[0]->{'geometry'}->{'location'}->{'lng'};
    }
    $arr = array($lat , $long);
    return $arr;
}
?>
