<?php
ini_set('memory_limit', '-1');
@session_start();
ob_start();
// include("../includes/check-session.php");

// if($_SESSION['user']['type'] != "operator"){
// 	header("Location: dashboard.php");
// 	exit();
// }
include("../connect.php");
include("../functions.php");
$checkTime = time();
if(isset($_FILES['file']['tmp_name'][0])){
	$rosterName = time()."_".$_FILES['file']['name'][0];
	$rosterPath = $_SERVER['DOCUMENT_ROOT'].DIRECTORY_SEPARATOR."route".DIRECTORY_SEPARATOR."uploads".DIRECTORY_SEPARATOR.$rosterName;

	$extensionArray = array("xls", "xlsx");
	$path_parts = pathinfo($_FILES["file"]["name"][0]);
	$extension = strtolower($path_parts['extension']);
	if(in_array($extension, $extensionArray)){
		if(move_uploaded_file($_FILES['file']['tmp_name'][0], $rosterPath)){
			$contentArray = array();
			$contentArray['excelname'] = $rosterName;
			$contentArray['createdon'] = time();
			$rosterId = addData("route_excel", $contentArray);
			$returnData['filename'] = $rosterName;

			set_include_path(get_include_path() . PATH_SEPARATOR . 'Classes/');

			/** PHPExcel_IOFactory */
			include '../excel/Classes/PHPExcel/IOFactory.php';
			$objPHPExcel = PHPExcel_IOFactory::load($rosterPath);
			$sheetData = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
			$returnData['totalRows'] = count($sheetData);
			$returnData['rosterId'] = $rosterId;
			echo json_encode($returnData);
		}
	}
}


?>
