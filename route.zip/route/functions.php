<?php
$URL = "http://dev.dynakode.in/indigo/";
$uploadFolder = "uploads";
$thumbFolder = "uploads" . DIRECTORY_SEPARATOR . "thumb";
$presFolder = "prescriptions";
$presThumbFolder = "prescriptions" . DIRECTORY_SEPARATOR . "thumb";

$thumbPath = "product_images". DIRECTORY_SEPARATOR . "100";
$mediumPath = "product_images". DIRECTORY_SEPARATOR . "328";
$largePath = "product_images". DIRECTORY_SEPARATOR . "1000";

//SMS CREDENTIALS
$smsUser = "mchemist364222";
$smsPass = "5828";
$smsSender = "MCHEMI";
$driverUploadFolderName = "driverphoto";
$driverImagePath = $_SERVER['DOCUMENT_ROOT'].DIRECTORY_SEPARATOR."indigo".DIRECTORY_SEPARATOR."driverphoto";

function createPassword(){
    $pass = '';
    $array = array('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
                    'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
                    '1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
    for($i=0; $i<8; $i++){
        $rand = rand(0, 35);
        $pass = $pass.$array[$rand];
    }
    return $pass;
}

function getChildCategory($parent, $catId, $parentId){
    $child="SELECT * FROM tbl_product_category where parentid=:parent and identifier!=:id";
	$core=Core::getInstance();
	$reschild=$core->dbh->prepare($child);
	$reschild->execute(array(':parent'=>$parent, ':id'=>$catId));
	if($reschild->rowCount()){
		$i++;
		while($recchild=$reschild->fetch(PDO::FETCH_ASSOC)){
			if($recchild['identifier'] == $parentId)
				$selected = 'selected="selected"';
			else
				$selected = "";
			echo '<option value="'.$recchild['identifier'].'" '.$selected.'>';
			$j=0;
			while($j<$i){
				echo '--';
				$j++;
			}

			echo $recchild['label'].'</option>';

			getChildCategory($recchild['identifier'], $catId, $parentId);

		}
	}
	else{
		return;
	}
}

function recursiveCall($parent){
	$child="SELECT * FROM tbl_menu where parentid=:parent ORDER BY ordering ASC";
	$core=Core::getInstance();
	$reschild=$core->dbh->prepare($child);
	$reschild->execute(array(':parent'=>$parent));
	if($reschild->rowCount()){
		echo '<ol class="dd-list">';
		while($recchild=$reschild->fetch(PDO::FETCH_ASSOC)){
			echo '<li data-id="'.$recchild['id'].'" class="dd-item">
				<div class="dd-handle">'.$recchild['label'].'</div>
				<div class="menuOption">
                      <a href="#editBox" title="Edit" class="fancybox"><span class="editMenu fa fa-edit" rel="'.$recchild['label'].'" id="menuid_'.$recchild['id'].'"><span></a> |
                      <a title="Delete" href="javascript:void(0)"><span class="deleteMenu fa fa-trash" id="menu_'.$recchild['id'].'"><span></a>
                </div>';
			recursiveCall($recchild['id']);
			echo "</li>";
		}
		echo '</ol>';
	}
	else{
		return;
	}
}

function recursiveMenu($id, $i, $parent){
	$child="SELECT * FROM tbl_menu where parentid=:parent";
	$core=Core::getInstance();
	$reschild=$core->dbh->prepare($child);
	$reschild->execute(array(':parent'=>$id));
	if($reschild->rowCount()){
		$i++;
		while($recchild=$reschild->fetch(PDO::FETCH_ASSOC)){
			if($recchild['identifier'] == $parent)
				$selected = 'selected="selected"';
			else
				$selected = "";
			echo '<option value="'.$recchild['identifier'].'" '.$selected.'>';
			$j=0;
			while($j<$i){
				echo '--';
				$j++;
			}

			echo $recchild['label'].'</option>';

			recursiveMenu($recchild['identifier'], $i, $parent);

		}
	}
	else{
		return;
	}
}

function addData($table, $contentData) {
	$content = array();
	$column = "";
	$columnKey = "";
	foreach($contentData as $key=>$data){
		$content[':'.$key] = $data;
        $column = $column."`".$key."`".",";
		$columnKey = $columnKey.":".$key.",";
	}
	$columnKey = rtrim($columnKey, ",");
	$column = rtrim($column, ",");
	$column = "(".$column.")";
	$columnKey = "(".$columnKey.")";
	$insert = "INSERT INTO ".$table." ".$column." VALUES ".$columnKey;
	$core = Core::getInstance();
	$result = $core->dbh->prepare($insert);
	$result->execute($content);
	$lastId = $core->dbh->lastInsertId();
	return $lastId;
}

function updateData($table, $contentData, $column, $id){
	$content = array();
	$columnKey = "";
	foreach($contentData as $key=>$data){
		$content[':'.$key] = $data;
		$columnKey = $columnKey."`".$key."`"."=:".$key.",";
	}
	$columnKey = rtrim($columnKey, ",");
	$update = "UPDATE ".$table." SET ".$columnKey." WHERE ".$column."=:".$column;
	$content[':'.$column] = $id;
	$core = Core::getInstance();
	$result = $core->dbh->prepare($update);
	$result->execute($content);
	$lastId = $id;
	return $lastId;
}

function fetchData($query, $array=array(), &$totalCount){
	$select = $query;
	$core = Core::getInstance();
	$result = $core->dbh->prepare($select);
	$result->execute($array);
    $totalCount = $result->rowCount();
	$dataRecord = array();
	while($record = $result->fetch(PDO::FETCH_ASSOC)){
		array_push($dataRecord, $record);
	}
	return $dataRecord;
}

function countData($query, &$totalCount, $array = array()){
	$select = $query;
	$core = Core::getInstance();
	$result = $core->dbh->prepare($select);
	$result->execute($array);
	$totalCount = $result->rowCount();
}

function get_media_name($id)
{
    $name = "";
	$select = "SELECT * FROM tbl_media_library WHERE identifier = :id LIMIT 0,1";
    $core = Core::getInstance();
    $result = $core->dbh->prepare($select);
    $result->execute(array(":id"=>$id));
    $count = $result->rowCount();
    if($count)
    {
        $row = $result->fetch(PDO::FETCH_ASSOC);
        $name = $row['name'];
    }
    return $name;
}
function get_product_image_name($id)
{
    $name = "";
	$select = "SELECT * FROM tbl_product_library WHERE identifier = :id LIMIT 0,1";
    $core = Core::getInstance();
    $result = $core->dbh->prepare($select);
    $result->execute(array(":id"=>$id));
    $count = $result->rowCount();
    if($count)
    {
        $row = $result->fetch(PDO::FETCH_ASSOC);
        $name = $row['imagename'];
    }
    return $name;
}

function delete($table, $contentData){
	global $pageURL;
    $i = 0;
	$where = "";
	$content = array();

	foreach($contentData as $key=>$data){
		$content[':'.$key] = $data;
		if($i == 0)
			$where = $where." WHERE ".$key."=:".$key;
		else
			$where = $where." AND ".$key."=:".$key;
	}
    //addData("tbl_log", array('deleted_value'=>$table.$where, 'templatename'=>$pageURL));
	$query = "DELETE FROM ".$table.$where;
	$core = Core::getInstance();
	$result = $core->dbh->prepare($query);
	$result->execute($content);
}
function checkShortcode($content, &$shortCodes){
    //$regex = "/\[\[([a-zA-Z\]\]]+)]/";
    $regex = "/\[\[([a-zA-Z]+)\]\]/";
    $restContent = preg_split($regex, $content);
    preg_match_all($regex, $content, $shortCodes);
    return $restContent;
}

function checkEmail($id, $email){
    $select = "SELECT * FROM tbl_user where identifier!=:id and email=:email";
    $core = Core::getInstance();
    $result = $core->dbh->prepare($select);
    $result->execute(array(':id'=>$id, ':email'=>$email));
    if($result->rowCount()){
        return true;
    }else{
        return false;
    }
}

function checkEmployeeEmail($id, $email){
    $select = "SELECT * FROM tbl_employee where identifier!=:id and email=:email";
    $core = Core::getInstance();
    $result = $core->dbh->prepare($select);
    $result->execute(array(':id'=>$id, ':email'=>$email));
    if($result->rowCount()){
        return true;
    }else{
        return false;
    }
}

function checkPatient($name, $dob, $userid){
    $patientId = 0;
    $select = "SELECT * FROM tbl_patient where patient=:patient and dob between :from AND :to and userid=:user";
    $dobTo = $dob + 24*3600 -1;
    $core = Core::getInstance();
    $res = $core->dbh->prepare($select);
    $res->execute(array(':patient'=>$name, ':from'=>$dob, ':to'=>$dobTo, ':user'=>$userid));
    if($res->rowCount()){
        $rec = $res->fetch(PDO::FETCH_ASSOC);
        $patientId = $rec['identifier'];
    }
    return $patientId;
}
function formatFileName($value)
{
	$text = preg_replace('~[^\\pL\d]+~u', '-', $value);
	$text = trim($text, '-');
	$text = strtolower($text);
	$text = preg_replace('~[^-\w]+~', '', $text);
	return $text;
}

function getTrasnportar(){
    global $_SESSION;
	$select = "SELECT * FROM tbl_user where type like 'transportar' and is_active like 'Y' and updatedby=:updatedby";
	$counter = 0;
	$data = fetchData($select, array(":updatedby"=>$_SESSION['user']['identifier']), $counter);
	return $data;
}

function deleteEmpTransRelation($empId){
	$delete = "DELETE FROM tbl_emp_trans_relation where employeeid=:employee";
	$core = Core::getInstance();
	$result = $core->dbh->prepare($delete);
	$result->execute(array(":employee"=>$empId));
}

function checkCarAndDriver($table, $id){
	global $_SESSION;
	$select = "SELECT * FROM ".$table." WHERE identifier=:id and transporterid=:trans";
	$core = Core::getInstance();
	$result = $core->dbh->prepare($select);
	$result->execute(array(":id"=>$id, ":trans"=>$_SESSION['user']['identifier']));
	if($result->rowCount()){
		return true;
	}else{
		return false;
	}
}

function checkEmployee($email, $identifier){
	$select = "SELECT * FROM tbl_employee where identifier=:id and email like :email and is_active='Y'";
	$counter = 0;
	$data = fetchData($select, array(":id"=>$identifier, ":email"=>$email), $counter);
	if($counter){
		return true;
	}else{
		return false;
	}
}

function timeAgo($ptime) {
    $etime = time() - $ptime;

    if ($etime < 1) {
        return '0 seconds';
    }

    $a = array( 12 * 30 * 24 * 60 * 60  =>  'year',
                30 * 24 * 60 * 60       =>  'month',
                24 * 60 * 60            =>  'day',
                60 * 60                 =>  'hour',
                60                      =>  'minute',
                1                       =>  'second'
                );

    foreach ($a as $secs => $str) {
        $d = $etime / $secs;
        if ($d >= 1) {
            $r = round($d);
            return $r . ' ' . $str . ($r > 1 ? 's' : '');
        }
    }
}

function getConfigurationValue($metaKey){
	$val = 0;
	$select = "SELECT * FROM tbl_configuration where metakey like :key";
	$core = Core::getInstance();
	$result = $core->dbh->prepare($select);
	$result->execute(array(":key"=>$metaKey));
	if($result->rowCount()){
		$record = $result->fetch(PDO::FETCH_ASSOC);
		$val = $record['metavalue'];
	}
	return $val;
}

function getEmployeeId($email){
	$id = 0;
	$select = "SELECT * FROM tbl_employee where email like :email and is_active='Y'";
	$core = Core::getInstance();
	$result = $core->dbh->prepare($select);
	$result->execute(array(":email"=>$email));
	if($result->rowCount()){
		$record = $result->fetch(PDO::FETCH_ASSOC);
		$id = $record['identifier'];
	}
	return $id;
}

function sendSMS($phone, $msg){
	global $smsUser, $smsPass, $smsSender;
	date_default_timezone_set("Asia/Kolkata");
    $url= "http://bhashsms.com/api/sendmsg.php?user=9999366694&pass=dynavision&sender=DYKODE&phone=".$phone."&text=".urlencode($msg)."&priority=ndnd&stype=normal";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $url );
    $curl_result = curl_exec($ch);
    curl_close($ch);
    // $smsArray = array();
    // $smsArray['phone']  =   $phone;
    // $smsArray['msg']    =   $msg;
    // $smsArray['time']   =   date('d-m-Y G:i:s');
    // addData('tbl_sms',$smsArray);
    return true;
}

function sendMessageThroughGCM($userid, $message, $type, $image="", $patientid=0) {
	//Google cloud messaging GCM-API url
	$select = "SELECT * FROM tbl_gcm_token where employeeid=:user";
	$count = 0;
	$data = fetchData($select, array(":user"=>$userid), $count);
	$url = 'https://android.googleapis.com/gcm/send';
	foreach($data as $token){
		$registatoin_ids = array($token['gcmtoken']);
		$fields = array(
			'registration_ids' => $registatoin_ids,
			'data' => array("msg"=>$message, "type"=>$type, "image"=>$image),
		);
		// Update your Google Cloud Messaging API Key
		define("GOOGLE_API_KEY", "AIzaSyACsX1727ZAjAsO9fhmc0pWls83nEa2Oq8");
		$headers = array(
			'Authorization: key=' . GOOGLE_API_KEY,
			'Content-Type: application/json'
		);
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
		$result = curl_exec($ch);
		if ($result === FALSE) {
			die('Curl failed: ' . curl_error($ch));
		}
		curl_close($ch);
	}
	//ADD DATA INTO NOTIFICATION TABLE
	// if($count){
	// 	$contentData = array("userid"=>$userid, "message"=>$message, "flag"=>0, "prescriptionid"=>$presId, "patientid"=>$patientid, "datetime"=>time(), "type"=>$type);
	// 	$insertId = addData("tbl_notification_msg", $contentData);
	// }
}
?>
