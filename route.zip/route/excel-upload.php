<?php
include("connect.php");
include("functions.php");
?>
<html>
<head>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/AdminLTE.min.css">
</head>
<body>
	<section class="content">
	      <div class="row">

	        <!--DATA TABLE-->

	        <!--ADD NEW DATA-->
	        <div class="col-md-12">
	          <div class="box box-success">
	            <div class="box-header with-border">
	              <h3 class="box-title">Upload New File</h3>
	            </div><!-- /.box-header -->
	            <!-- form start -->
	            <form id="my-awesome-dropzone" class="dropzone" method="post" action="ajax/uploadroster.php">
	              <div class="box-body">
	                <div class="callout callout-danger" id="jqueryError" style="display:none;">
	                </div>


	                <div class="row">
	                  <div class="dropzone-previews"></div>
	                </div>
	              </div><!-- /.box-body -->
	            </form>
	            <div class="box-footer">
	              <input class="btn btn-success" type="submit" id="formsubmit" name="submit" value="Upload" />
	            </div><!-- /.box-footer -->

	          </div>
	        </div>
	        <!--END ADD NEW DATA-->


	      </div>
	    </section><!-- /.content -->

	    <div class="modal fade" id="myModal" role="dialog">
	        <div class="modal-dialog">

	          <!-- Modal content-->
	          <div class="modal-content">
	            <div class="modal-header">
	              <h4 class="modal-title">Progress Update</h4>
	            </div>
	            <div class="modal-body">
	                <div class="progress">
	                    <div class="progress-bar progress-bar-primary progress-bar-striped progress-bar-green" role="progressbar" id="progress-bar-excel" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
	                      <span class="sr-only">40% Complete (success)</span>
	                    </div>
	                </div>
	            </div>
	          </div>

	        </div>
	    </div>
<link rel="stylesheet" href="dropzone/dropzone.css" />
<script src="jQuery-2.1.4.min.js"></script>
<script src="dropzone/dropzone.min.js"></script>
<script src="bootstrap.min.js"></script>

<script>
$(document).ready(function(){

	function processData(fileName, totalRows, rosterId){
        for(var i=1; i<=totalRows;i++){
            $.ajax({
                type:"post",
                data:{rowNumber:i, filename: fileName, rosterId: rosterId},
                url:"ajax/process-row.php",
                success:function(data){
                    var perc = 100;
                    var jsonData = $.parseJSON(data);
                    var totalRows = jsonData.totalRows;

                    var end = jsonData.end;
                    var rowNumber = jsonData.rowNumber;
                    var fileName = jsonData.fileName;
                    if(totalRows != "0"){
                        perc = (rowNumber-1)*100/totalRows;
                        var percent = perc+"%";
                        $("#progress-bar-excel").css("width", percent);
                    }
                    if(end != "1"){
                        console.log(perc);
                        //processData(rowNumber, fileName);
                    }else{
                        return;
                    }
                },
                async:false
            });
        }
		$("#myModal").modal("hide");
		window.location.reload(true);
    }

	Dropzone.options.myAwesomeDropzone = {
    init: function() {
      var myDropzone = this;
      //console.log("Call init function");
      // First change the button to actually tell Dropzone to process the queue.
      document.getElementById("formsubmit").addEventListener("click", function(e) {
        $("#formsubmit").attr("disabled", true);
        var showme = myDropzone.files;
        if (showme==""){
          $( "#comment").submit();
        }else{

        }
        e.preventDefault();
        e.stopPropagation();
        myDropzone.processQueue();
      });

      // Listen to the sendingmultiple event. In this case, it's the sendingmultiple event instead
      // of the sending event because uploadMultiple is set to true.
      this.on("sendingmultiple", function() {
        // Gets triggered when the form is actually being sent.
        // Hide the success button or the complete form.
      });
      this.on("successmultiple", function(files, response) {
        // Gets triggered when the files have successfully been sent.
        // Redirect user or notify of success.
        console.log(files);
        var data = $.parseJSON(response);
        var fileName = data.filename;
        var totalRows = data.totalRows;
        var rosterId = data.rosterId;
		$("#myModal").modal({
			backdrop: 'static',
	    	keyboard: false
		});
        $('#myModal').modal('show');
        processData(fileName, totalRows, rosterId);
      });
      this.on("errormultiple", function(files, response) {
        // Gets triggered when there was an error sending the files.
        // Maybe show form again, and notify user of error
      });
    },
    autoProcessQueue: false,
    uploadMultiple: true,
    parallelUploads: 100,
    maxFiles: 1
  }
})
</script>
</body>
</html>
