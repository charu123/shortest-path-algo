<?php
 include("connect.php");
   include("functions.php");
$id = isset($_GET['id'])?$_GET['id']:0;
if(!intval($id)){
    $id = 0;
}
if($id !== 0){
    $query = "SELECT * FROM route_excel_data where excelid=:report ORDER BY identifier asc";
    $counter = 0;
    $data = fetchData($query, array(":report"=>$id), $counter);
}else{
    echo "Nothing";
    exit();
}
?>
<html>
<head>
 <link href="mapapi/css/UI/ZoomControl.css" rel="stylesheet">

</head>
<body>



<div class="content-wrapper">
      <div id="mapContainer"></div>
</div>

<style>
#mapContainer
  {
    height: 100%;
    width: 100%;
    position:absolute;
    top:0;
    left:0;

  }
  .deCarta-InfoWindow-Content{
    min-width:300px;
    padding:7px;
    min-height:90px;
  }
</style>
<script src="jQuery-2.1.4.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCOeXt8ypp3kJZrttZWQrpCZiEgPrY9P1k&callback=initMap"></script>

<script>
var center = {lat:<?php echo $data[0]['latitude']?>, lng:<?php echo $data[0]['longitude']?>};
var map;
function initMap() {
    map = new google.maps.Map(document.getElementById('mapContainer'), {
        center: center,
        zoom: 8
    });

    var markers = [
        <?php for($i=0;$i<=count($currentDetails);$i++){
            $currentDetails = $data[$i];
        ?>
            {
                "title": '<?php echo $currentDetails['customer']?>',
                "lat": '<?php echo $currentDetails['latitude']?>',
                "lng": '<?php echo $currentDetails['longitude']?>',
                "description": '<b>Customer Name:</b><?php echo $currentDetails['customer']?><br /><b>Address: </b><?php echo $currentDetails['address']."<br>".$currentDetails['address2']."<br>".$currentDetails['city']."-".$currentDetails['pincode']?>'
            },
        <?php }?>
    ];

    var infoWindow = new google.maps.InfoWindow();
    var lat_lng = new Array();
    var latlngbounds = new google.maps.LatLngBounds();
    for (i = 0; i < markers.length; i++) {
        var data = markers[i]
        var myLatlng = new google.maps.LatLng(data.lat, data.lng);
        lat_lng.push(myLatlng);

    }
    map.setCenter(latlngbounds.getCenter());
    map.fitBounds(latlngbounds);



    var wayPoints = [];
    for(var i = 1; i < lat_lng.length-1;i++){
        wayPoints.push({
            location: lat_lng[i],
            stopover: true
        });
    }

    var directionsService = new google.maps.DirectionsService;
    var directionsDisplay = new google.maps.DirectionsRenderer;

    directionsService.route({
        origin: lat_lng[0],
        destination: lat_lng[0],
        waypoints: wayPoints,
        optimizeWaypoints: true,
        travelMode: google.maps.TravelMode.DRIVING
    }, function(response, status) {
        if (status === google.maps.DirectionsStatus.OK) {
            directionsDisplay.setDirections(response);
            var route = response.routes[0];

        } else {
            window.alert('Directions request failed due to ' + status);
        }
    });
    // console.log(directionsDisplay);
    // console.log(directionsService);
    directionsDisplay.setMap(map);
}
</script>

<!-- <script src="deCarta.JS4.js"></script>

<script src="Config.js"></script>
  <script src="mapapi/js/UI/ZoomControl.js"></script>
<script>
  deCarta.Core.Configuration.AppKey = Config.AppKey;
</script>

<script>
$(document).ready(function(){
<?php if(count($data)){?>
 var center = new deCarta.Core.Position(<?php echo $data[0]['latitude'];?>,<?php echo $data[0]['longitude'];?>);
<?php }else{?>
    var center = new deCarta.Core.Position(28.55576888888889,77.37284444444444);
<?php }?>
  var pinOverlay = new deCarta.Core.MapOverlay({
    name: "Pins"
  });

    var routeOverlay = new deCarta.Core.MapOverlay({
        name: 'route'
    });

  var controls = [];
  controls.push(new deCarta.UI.ZoomControl({position: 'leftTop'}));
  <?php


    $i = 1;
    foreach($data as $currentDetails){
        if($i == 1){
            $pinImage = "green_pointer.png";
        }else if($i == count($data)){
            $pinImage = "red_pointer.png";
        }else{
            $pinImage = "pointer.png";
        }
    ?>

      var div<?php echo $i;?> = document.createElement("div");
      div<?php echo $i;?>.style.height="20px"
      div<?php echo $i?>.className="<?php echo 'pinPointer'.$i;?>"
      div<?php echo $i;?>.style.width="20px"
      div<?php echo $i;?>.style.borderRadius="1em"
      div<?php echo $i;?>.style.color="yellow";
      div<?php echo $i;?>.style.textShadow="1px 1px 0 #333";
      div<?php echo $i;?>.style.backgroundImage="url(img/<?php echo $pinImage;?>)"

    var carPointer = new deCarta.Core.Position(<?php echo   $currentDetails['latitude'];?>,<?php echo   $currentDetails['longitude'];?>);

    var pin<?php echo $i;?> = new deCarta.Core.Pin({
      position: carPointer.clone(),
      image:div<?php echo $i;?>,
      text: ''
    })

  <?php $i++;}?>
  window.map = new deCarta.Core.Map({
    id: "mapContainer",
    zoom: 12,
    center: center,
    controls: controls,
    scrollWheelEnabled: false,
    onReady: function(map){

      map.addLayer(pinOverlay);

      var routeCriteria = new deCarta.Core.RouteCriteria();
        map.addOverlay(routeOverlay);
        routeCriteria.waypoints = [
             new deCarta.Core.Position(28.5388599,77.2221931),
             new deCarta.Core.Position(28.6568263, 77.3180611)
        ];

        routeCriteria.maneuverMaps = true;

        deCarta.Core.Routing.execute(routeCriteria, function(route, error){

            var line = new deCarta.Core.Polyline({
                lineGeometry: route.routeGeometry
            })

            var centerAndZoom = line.getIdealCenterAndZoom(map);

            routeOverlay.addObject(line);
            map.zoomTo(centerAndZoom.zoom);
            map.centerOn(centerAndZoom.center);
        })

     // pinOverlay.addObject(pin);

      <?php
        $i = 1;
        foreach($data as $currentDetails){?>
        pinOverlay.addObject(pin<?php echo $i;?>);
      <?php $i++;}?>

      mapCreated = true;

    }

  });

  console.log(window.map);
})
</script> -->

</body>

</html>
