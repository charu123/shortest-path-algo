var Config = {	
	AppKey: "fb0c58839af547869f409e9134bc1e08", // API KEY from your account on developer.decarta.com
	position : "37.595463875285624, -122.38941192626953"	
}

if(!Config.AppKey) alert("Opps! That didn't work...\n\nTo view the examples you need to provide your API KEY. \n\nSee Config.js for intructions.");

deCarta.Core.Configuration.url = "http://api.decarta.com";
deCarta.Core.Configuration.defaultConfig="global-decarta"; // or global-tomtom
deCarta.Core.Configuration.tileResolution = 'hdpi'; // mdpi,hdpi,xhdpi,xxhdpi
deCarta.Core.Configuration.resourceTimeout = 20000;
deCarta.Core.Configuration.requestTimeout= 15000;
deCarta.Core.Configuration.imgPath= "img/";
