<?php
    $result = exec("java -jar Test.jar", $output);
    var_dump($output);
    var_dump($result);
?>
