<html>
<head>
</head>
<body>
<div>
    <p>
        <label>Server</label>
        <select name="server" class="server">
            <option value="">Select Server</option>
            <option value="1">Tata Fleet Man</option>
            <option value="2">AXESTRACK</option>
        </select>
    </p>
    <p class="axesuserp" style="display:none;">
        <label>User</label>
        <select class="useraxes">
            <option value="">Select User</option>
            <option value="1">DBRC1</option>
            <option value="2">DBRC2</option>
        </select>
    </p>
    <p class="tatauserp" style="display:none;">
        <label>User</label>
        <select class="usertata">
            <option value="">Select User</option>
            <option value="1">Bawejjugal</option>
            <option value="2">dbrc47@gmail.com</option>
        </select>
    </p>
    <p>
        <label>&nbsp;</label>
        <input type="submit" name="submit" value="Submit" id="submitBtn" />
    </p>

    <form method="post" action="https://tatafleetman.microlise.com/Live/TATAMotors/PreTenancy/Authentication/login" id="tataform">
        <input type="hidden" name="UserNameValue" value="" id="UserNameValue">
        <input type="hidden" name="PasswordValue" value="" id="PasswordValue">
    </form>

    <form method="get" action="http://locator.axestrack.com" id="axesform">
        <input type="hidden" name="un" value="" id="un">
        <input type="hidden" name="pw" value="" id="pw">
    </form>

    <form method="post" action="http://www.tatafleetman.com/index.php/welcome/login" id="tataform2">
        <input type="hidden" name="username" value="" id="tatauser2">
        <input type="hidden" name="passwd" value="" id="tatapass2">
        <input type="submit" name="submit" value="Login" style="display:none;" id="submitFormBtn"/>
    </form>
</div>

<script src="jQuery-2.1.4.min.js"></script>
<SCRIPT>
$(document).ready(function(){
    $(".server").change(function(){
        var value = $(this).val();
        if(value=="1"){
            $(".axesuserp").hide();
            $(".tatauserp").show();
        }else if(value=="2"){
            $(".tatauserp").hide();
            $(".axesuserp").show();
        }else{
            $(".tatauserp").hide();
            $(".axesuserp").hide();
        }
    });

    $(".usertata").change(function(){
        var value = $(this).val();
        if(value=="1"){
            $("#tatauser2").val("bawejjugal");
            $("#tatapass2").val("tata2014");
            $("#UserNameValue").val("");
            $("#PasswordValue").val("");
        }else if(value=="2"){
            $("#UserNameValue").val("dbrc47@gmail.com");
            $("#PasswordValue").val("delhi480");
            $("#tatauser2").val("");
            $("#tatapass2").val("");
        }else{
            $("#UserNameValue").val("");
            $("#PasswordValue").val("");
            $("#tatauser2").val("");
            $("#tatapass2").val("");
        }
    });

    $(".useraxes").change(function(){
        var value = $(this).val();
        if(value=="1"){
            $("#un").val("dbrc1");
            $("#pw").val("password");
        }else if(value=="2"){
            $("#un").val("dbrc2");
            $("#pw").val("123456");
        }else{
            $("#un").val("");
            $("#pw").val("");
        }
    })

    $("#submitBtn").click(function(){
        var server = $(".server").val();

        if(server == "1"){
            var user = $(".usertata").val();

            if(user == "1"){
                $("#submitFormBtn").trigger("click");
                //$("#tataform2").submit();
            }

            else if(user == "2"){
                $("#tataform").submit();

            }else{
                alert("Please Select User First");
            }
        }

        else if(server == "2"){
            var user = $("#un").val();
            if(user == ""){
                alert("Please Select User First");
            }else{
                $("#axesform").submit();
            }
        }
    })
})
</SCRIPT>
</body>

</html>
